package com.virus;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.*;
import java.sql.*;
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		Connection con = null;
		HttpSession session = request.getSession();
		RequestDispatcher dispatcher = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/virus","virusservlet","0000");
			PreparedStatement pst = con.prepareStatement("SELECT FirstName FROM User WHERE Email= ? and Password= ?");
			pst.setString(1, email);
			pst.setString(2, password);
			ResultSet rs = pst.executeQuery();
			if(rs.next()) {
				session.setAttribute("name", rs.getString("FirstName"));
				PreparedStatement pst1 = con.prepareStatement("SELECT UserRole FROM User WHERE Email= ? and Password= ?");
				pst1.setString(1, email);
				pst1.setString(2, password);
				ResultSet rs1 = pst1.executeQuery();
				if(rs1.next()) {
					session.setAttribute("userrole", rs1.getString("UserRole"));
				}
				dispatcher = request.getRequestDispatcher("index.jsp");
			}else {
				request.setAttribute("status", "failed");
				dispatcher = request.getRequestDispatcher("login.jsp");
			}
			dispatcher.forward(request, response);
			}catch(Exception e) {
				e.printStackTrace();
		}
	}

}
